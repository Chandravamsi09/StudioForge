import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Tenant } from './entities/tenant.entity';
import { User } from './entities/user.entity';
import { Build } from './entities/build.entity';
import { Ticket } from './entities/ticket.entity';
import { AnalyticsEvent } from './entities/analytics-event.entity';
import { LiveOpsEvent } from './entities/live-ops-event.entity';
import { Subscription } from './entities/subscription.entity';

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const dbType = configService.get<string>('database.type', process.env.DB_TYPE || 'sqlite');
        if (dbType === 'postgres') {
          return {
            type: 'postgres' as const,
            host: configService.get<string>('database.host'),
            port: configService.get<number>('database.port'),
            username: configService.get<string>('database.username'),
            password: configService.get<string>('database.password'),
            database: configService.get<string>('database.database'),
            entities: [Tenant, User, Build, Ticket, AnalyticsEvent, LiveOpsEvent, Subscription],
            synchronize: configService.get<boolean>('database.synchronize', true),
            logging: false,
          };
        }
        return {
          type: 'sqlite' as const,
          database: 'studioforge.sqlite',
          entities: [Tenant, User, Build, Ticket, AnalyticsEvent, LiveOpsEvent, Subscription],
          synchronize: true,
          logging: false,
        };
      },
    }),
    TypeOrmModule.forFeature([Tenant, User, Build, Ticket, AnalyticsEvent, LiveOpsEvent, Subscription]),
  ],
  exports: [TypeOrmModule],
})
export class DatabaseModule {}
