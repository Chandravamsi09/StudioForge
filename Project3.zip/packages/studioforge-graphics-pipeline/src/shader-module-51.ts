/**
 * StudioForge PBR Graphics Shader Pipeline: GraphicsShaderModule_51
 * Implements GGX microfacet specular distribution, Smith geometric shadowing,
 * and Schlick-Fresnel approximations for real-time raytraced & rasterized lighting.
 */

export interface GraphicsShaderModule_51Uniforms {
  albedoMapResolution: number;
  roughnessFactor: number;
  metallicFactor: number;
  ambientOcclusionStrength: number;
  emissiveIntensity: number;
  clearcoatStrength: number;
  anisotropyAngle: number;
}

export class GraphicsShaderModule_51Pipeline {
  private uniforms: GraphicsShaderModule_51Uniforms;

  constructor(uniforms?: Partial<GraphicsShaderModule_51Uniforms>) {
    this.uniforms = {
      albedoMapResolution: 2048,
      roughnessFactor: 0.5,
      metallicFactor: 0.0,
      ambientOcclusionStrength: 1.0,
      emissiveIntensity: 0.0,
      clearcoatStrength: 0.0,
      anisotropyAngle: 0.0,
      ...uniforms,
    };
  }

  computeGGXDistribution(NdotH: number, roughness: number): number {
    const a = roughness * roughness;
    const a2 = a * a;
    const NdotH2 = NdotH * NdotH;
    const denom = NdotH2 * (a2 - 1.0) + 1.0;
    return a2 / (Math.PI * denom * denom + 0.000001);
  }

  computeSchlickFresnel(cosTheta: number, F0: number): number {
    return F0 + (1.0 - F0) * Math.pow(Math.max(0, 1.0 - cosTheta), 5.0);
  }

  computeSmithVisibility(NdotV: number, NdotL: number, roughness: number): number {
    const r = roughness + 1.0;
    const k = (r * r) / 8.0;
    const gv = NdotV / (NdotV * (1.0 - k) + k);
    const gl = NdotL / (NdotL * (1.0 - k) + k);
    return gv * gl;
  }
}
